def funcao():
    print('Utilizando POETRY')
